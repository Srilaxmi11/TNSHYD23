package userdefined2;

public class C {
	
	public void msg() {
		System.out.println("Hello D");
	}

}