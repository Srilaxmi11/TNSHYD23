package userdefined;

import userdefined1.A;
import userdefined1.B;
import userdefined2.C;

public class D {

	public static void main(String[] args) {
		
		 A obj=new A();
		 B obj1=new B();
		 C obj2=new C();
		 
		 obj.msg();
		 obj1.msg();
		 obj2.msg();
		 
	

	}

}
