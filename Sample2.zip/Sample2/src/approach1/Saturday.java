package approach1;

public class Saturday {
	
	int a=1;
	static int b=2;
	
	int display() {
		return a;
	}
	
	static void display1() {
		System.out.println(b);
	}

	public static void main(String[] args) {
		
		Saturday obj=new Saturday();
		System.out.println(obj.a);
		obj.display();
		
		System.out.println(Saturday.b);
		Saturday.display1();

	}

}
