package approach2;


public class Demo {

	public static void main(String[] args) {
		
		Sample obj=new Sample();
		System.out.println(obj.x);
		obj.show();
		
		System.out.println(Sample.y);
		Sample.show1();

	}

}
