package approach2;

public class Sample {
	
	int x=10;
	static int y=20;
	
	int show() {
		return x;
	}
	
	static void show1() {
		System.out.println(y);
	}

}
