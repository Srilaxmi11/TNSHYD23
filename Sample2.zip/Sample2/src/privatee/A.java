package privatee;

public class A {
	
	private void display(){
		System.out.println("Sessions");
	}

	public static void main(String[] args) {
		
		A obj=new A();
		obj.display();


	}

}
