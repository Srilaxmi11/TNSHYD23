package protectedd;

public class A {
	
	protected void display() {
		System.out.println("TNS Sessions");
	}


}
